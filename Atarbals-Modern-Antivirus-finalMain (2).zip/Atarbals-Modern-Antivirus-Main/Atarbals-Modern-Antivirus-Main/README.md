
# **INTRODUCING ATARBALS-MORDEN-ANTIVIRUS 1.0 FULLY FUNCTIONAL**
-----------------------------------------------------------------------------------------------------------------------------------------------------------



## This is official main version of Atarbals antivirus. 
### Launched on 8 November 2022 after 1 years of pause and 2 years of patience


<p align="center">
  <img width="400" src="https://user-images.githubusercontent.com/90396120/140484198-a5ea4094-42e3-4ee1-8ecb-999e0b6189cf.png" alt="logo">
  <h1 align="center" style="margin: 0 auto 0 auto;">Atarbals Mordern Antivirus</h1>
</p>

 <p align="center">
   <img src="https://img.shields.io/badge/Open%20Source-Atarbals%20Antivirus%20for%20all-brightgreen">
   <img src="https://img.shields.io/badge/Atarbals%20Antivirus-With%20Mordern%20UI-skyblue">
   <img src="https://img.shields.io/badge/Product%20Updates-On%20schedule-lightblue">
 </p>


___ 
## Requirments to work properly

1) `pip install pillow==9.0.0`
 
2) `python -m smtpd -c DebuggingServer -n localhost:1025`

## 💡 Introduction
I am Harsh Chaudhari. I was born in 2007 in India. I started HarshscGithub project on GitHub at 9 of November 2020. I started this project with my first launch of Dashing AntiVirus in December 2021. Dashing Antivirus was basically just an idea of Ki-Lo Antivirus but I had no intention of making Ki-Lo Antivirus. But Dashing Antivirus was too poor so after Ki-Lo Antivirus 2.5 launch Dashing Antivirus was inserted in Ki-Lo Antivirus Repository. Now I have been talking about Ki-Lo Antivirus so let me tell something about it. After Dashing Antivirus Launch (Dec 2020) I went offline because of no interest in Github then came online again in 18 July 2021 because of sudden intrest in Kilo-Antivirus 1.0 then 1.5 ... last version Kilo-Antivirus 2.5. 

This is whole new antivirus. This antivirus has modern UI and is written in Python 3.0 with Tkinter. This antivirus is prior to Ki-Lo antivirus 2.0. Atarbals Modern Antivirus's code is entirely re-written but it is still based on Ki-Lo Antivirus because it's too hard to change the fundamental of UI.

 <p align="left">
  <img width="500" alt="Tkinter Designer GUI" src="https://user-images.githubusercontent.com/90396120/139038255-0e84b18a-b5cf-4c27-96ea-22a46d9a357b.png">      
 </p>
 
 <p align="right">
  <img width="500" alt="Screenshot 2021-10-29 at 3 21 50 PM" src="https://user-images.githubusercontent.com/90396120/139414871-bec599c1-4c3d-45b5-bae9-c9921d3b999b.png">
 </p>
 
 ## You will recive this kind of email on registration 
 
  <p align="right">
 <img width="761" alt="Screenshot 2022-11-22 at 10 07 07 PM" src="https://user-images.githubusercontent.com/90396120/203483069-a75bba18-7540-41df-b7f1-8e57cc8a438d.png">

 </p>
___ 


## 🌐 Visit my website at : https://harshscgithub.wixsite.com/home
___

## ⚡️ Installing & Using AtarBals Mordern Antivirus

The instructions contain all the information about installing and using Tkinter Designer, along with information for troubleshooting and reporting issues. There is also a video.


### [Watch the Video](https://www.youtube.com/watch?v=_9y_uM-HjgA)  

___

## 📝 Contact Me

If you want to contact me, you can reach me at harshscgithub@gmail.com or at website https://harshscgithub.wixsite.com/home/contact .
___


## 📄 License

**Atarbals Modern Antivirus** is licensed under the
**GNU General Public License v3.0**

[View Here.](https://github.com/HarshscGithub/Atarbals-Modern-Antivirus/blob/Main/LICENSE)

| Permissions | Limitations | Conditions
| --- | --- | --- 
&check; Commercial Use | &times; Liability |&#x1f6c8; License and Copyright Notice
&check; Modification   | &times; Warranty  |&#x1f6c8; State Changes
&check; Distribution   |                   |&#x1f6c8; Disclose source
&check; Patent Use     |                   |&#x1f6c8; Same license
&check; Private Use    |                   

___
🆓 Get premium for free at : https://harshscgithub.wixsite.com/home/about-4 but when version 1.1.0 is released.

## Sorry Guys I have stopped the development of this project because I am completing my school syllabus and other olympiad stuff.
## I will again start this project with real antivirus that can scan virus and remove virus(if permission given for storage) some months or years later.
## If any one needs support or to Contibute to my project contact me at my email : harshscgithub@gmail.com or harshsc2007@gmail.com
## Message me if anyone need to contibute at above email.
## See you soon guys !
