import os
  
Picture_path = os.path.abspath("No_Virus_Found.png")

icon_path = os.path.abspath("Antivirus_Logo.png")

#First time run paths  

username_file_path = os.path.abspath("User_credn/usernames.txt")

password_file_path = os.path.abspath("User_credn/password.txt")

email_file_path = os.path.abspath("User_credn/email.txt")

purchase_file_path = os.path.abspath("User_credn/purchase.txt")

